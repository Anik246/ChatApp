package io.github.hridoy100;

public class Information {
    public String username;
    public NetworkConnection netConnection;
    public Information(String user, NetworkConnection nConnection){
        username=user;
        netConnection=nConnection;
    }

}
